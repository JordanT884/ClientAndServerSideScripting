<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Create New Questionnaire</div>
                <!-- Creates a button to enter the questionnaires -->
                <a href="/questionnaires/create" class="btn-dark">

                <div class="card-body">
                    <form action="questionnaires" method="post">

                    @csrf 
                    <!-- Form for the user to create their survey, asks for the title of the survey and the purpose  -->
                    <div class="form-group">
                        <label for="title">Title</label>
                        <input name="title" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="titleHelp" placeholder="Enter title">
                        <small id="titleHelp" class="form-text text-muted">Give your questionnaire a title.</small>
                    </div>

                     <div class="form-group">
                        <label for="purpose">Purpose</label>
                        <input name="purpose" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="purposeHelp" placeholder="Enter purpose">
                        <small id="purposeHelp" class="form-text text-muted">Give your questionnaire a purpose.</small>
                    </div>
                    <!-- Button to create the questionnaire -->
                    <button type="submit" class="btn btn-primary">Create Questionnaire</button>    

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>